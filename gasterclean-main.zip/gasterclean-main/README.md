<p>Build it with GCC, and Libusb by Msys2 by command "PATH=/mingw64/bin:$PATH gcc -Wall -Wextra -Wpedantic gaster.c -o gaster -lusb-1.0 -Os"<br>
Thanks 0x7ff for good exploit<br>
I need someone port it into C# or Delphi if you can message me at https://t.me/ductam_net <br>
Some link might help you:<br>
GCC: https://packages.msys2.org/package/mingw-w64-x86_64-gcc<br>
Libusb: https://packages.msys2.org/package/mingw-w64-x86_64-libusb<br>
Msys2: https://github.com/msys2/msys2-installer/releases<br></p>
